package com.garticai.player.core.draw

import com.garticai.player.domain.*
import java.text.Normalizer
import kotlin.math.*

/** Planejador OFFLINE (modo demonstração): desenhos prontos, em 5 fases, para poucas palavras. */
object LocalPlanner {
    val supportedWords = listOf("sol", "casa", "árvore", "flor", "peixe", "gato")

    fun normalize(w: String): String =
        Normalizer.normalize(w.trim().lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    fun plan(word: String): DrawingPlan? {
        val strokes = when (normalize(word)) {
            "sol" -> sun()
            "casa" -> house()
            "arvore" -> tree()
            "flor" -> flower()
            "peixe" -> fish()
            "gato" -> cat()
            else -> return null
        }
        return DrawingPlan(word.trim(), strokes)
    }

    private val SK = DrawPhase.SKETCH
    private val ST = DrawPhase.STRUCTURE
    private val DE = DrawPhase.DETAIL
    private val CO = DrawPhase.COLOR
    private val FI = DrawPhase.FINISH
    private const val GUIDE = "#C4C4C4"

    private fun sun() = listOf(
        s(SK, GUIDE, 2.0, ellipse(.5, .5, .2, .2)), s(SK, GUIDE, 2.0, pts(.5 to .2, .5 to .8)), s(SK, GUIDE, 2.0, pts(.2 to .5, .8 to .5)),
        s(ST, "#E6A100", 5.0, ellipse(.5, .5, .2, .2))
    ) + (0 until 12).map { i ->
        val a = 2 * PI * i / 12
        s(DE, "#FF8C00", 5.0, listOf(P(.5 + .25 * cos(a), .5 + .25 * sin(a)), P(.5 + .38 * cos(a), .5 + .38 * sin(a))))
    } + listOf(
        s(CO, "#FFD93B", w(.035), fillEllipse(.5, .5, .19, .19, .035)),
        s(FI, "#B87400", 3.0, ellipse(.5, .5, .2, .2)),
        s(FI, "#333333", 4.0, ellipse(.43, .45, .02, .03, 12)), s(FI, "#333333", 4.0, ellipse(.57, .45, .02, .03, 12)),
        s(FI, "#333333", 4.0, (0..16).map { val a = PI * (.15 + .7 * it / 16); P(.5 + .11 * cos(a), .53 + .09 * sin(a)) }),
        s(FI, "#FF9AA2", 6.0, ellipse(.38, .53, .02, .015, 10)), s(FI, "#FF9AA2", 6.0, ellipse(.62, .53, .02, .015, 10))
    )

    private fun house() = listOf(
        s(SK, GUIDE, 2.0, rect(.2, .45, .8, .85)), s(SK, GUIDE, 2.0, pts(.05 to .85, .95 to .85)),
        s(ST, "#444444", 5.0, rect(.25, .5, .75, .85)),
        s(ST, "#8B1A1A", 6.0, pts(.2 to .5, .5 to .22, .8 to .5, .2 to .5)),
        s(DE, "#555555", 4.0, pts(.62 to .38, .62 to .24, .7 to .24, .7 to .43)),
        s(DE, "#BBBBBB", 3.0, ellipse(.66, .19, .02, .02, 12)), s(DE, "#BBBBBB", 3.0, ellipse(.69, .13, .027, .027, 12)),
        s(DE, "#8B7355", 4.0, pts(.5 to .85, .45 to .95, .55 to .95, .5 to .85)),
        s(DE, "#7A7A7A", 3.0, pts(.82 to .85, .82 to .72, .95 to .72, .95 to .85)),
        s(DE, "#5DBB63", 3.0, pts(.08 to .85, .1 to .8, .12 to .85, .14 to .79, .16 to .85)),
        s(CO, "#F5D6A0", w(.04), fillRect(.26, .51, .74, .84, .04)),
        s(CO, "#C0392B", w(.03), fillTri(.5, .22, .5, .3, .24, .49, .03)),
        s(CO, "#8B5A2B", w(.03), fillRect(.46, .63, .56, .84, .03)),
        s(CO, "#8EC9F0", w(.025), fillRect(.31, .59, .39, .67, .025)), s(CO, "#8EC9F0", w(.025), fillRect(.61, .59, .69, .67, .025)),
        s(CO, "#7CB342", w(.03), fillRect(.05, .87, .95, .95, .03)),
        s(FI, "#222222", 3.0, rect(.25, .5, .75, .85)), s(FI, "#222222", 3.0, pts(.2 to .5, .5 to .22, .8 to .5, .2 to .5)),
        s(FI, "#222222", 3.0, rect(.45, .62, .57, .85)), s(FI, "#FFD54F", 4.0, ellipse(.54, .74, .008, .008, 8)),
        s(FI, "#222222", 3.0, rect(.3, .58, .4, .68)), s(FI, "#222222", 2.0, pts(.35 to .58, .35 to .68)), s(FI, "#222222", 2.0, pts(.3 to .63, .4 to .63)),
        s(FI, "#222222", 3.0, rect(.6, .58, .7, .68)), s(FI, "#222222", 2.0, pts(.65 to .58, .65 to .68)), s(FI, "#222222", 2.0, pts(.6 to .63, .7 to .63))
    )

    private fun tree() = listOf(
        s(SK, GUIDE, 2.0, ellipse(.5, .38, .3, .25)), s(SK, GUIDE, 2.0, pts(.5 to .6, .5 to .9)),
        s(ST, "#5D4037", 5.0, rect(.45, .55, .55, .88)),
        s(ST, "#2E7D32", 5.0, ellipse(.5, .33, .2, .18)), s(ST, "#2E7D32", 5.0, ellipse(.34, .45, .16, .14)), s(ST, "#2E7D32", 5.0, ellipse(.66, .45, .16, .14)),
        s(DE, "#8D6E63", 3.0, pts(.48 to .6, .48 to .85)), s(DE, "#8D6E63", 3.0, pts(.52 to .65, .52 to .8)),
        s(DE, "#7CB342", 3.0, pts(.05 to .88, .95 to .88)),
        s(DE, "#90A4AE", 3.0, ellipse(.18, .12, .08, .04, 20)), s(DE, "#90A4AE", 3.0, ellipse(.26, .1, .07, .05, 20)),
        s(CO, "#8D6E63", w(.025), fillRect(.46, .56, .54, .87, .025)),
        s(CO, "#43A047", w(.03), fillEllipse(.5, .33, .19, .17, .03)),
        s(CO, "#43A047", w(.03), fillEllipse(.34, .45, .15, .13, .03)), s(CO, "#43A047", w(.03), fillEllipse(.66, .45, .15, .13, .03)),
        s(CO, "#7CB342", w(.03), fillRect(.05, .89, .95, .96, .03)),
        s(FI, "#1B5E20", 3.0, ellipse(.5, .33, .2, .18)), s(FI, "#1B5E20", 3.0, ellipse(.34, .45, .16, .14)), s(FI, "#1B5E20", 3.0, ellipse(.66, .45, .16, .14)),
        s(FI, "#E53935", 7.0, fillEllipse(.42, .3, .02, .02, .01)), s(FI, "#E53935", 7.0, fillEllipse(.58, .38, .02, .02, .01)),
        s(FI, "#E53935", 7.0, fillEllipse(.3, .47, .02, .02, .01)), s(FI, "#E53935", 7.0, fillEllipse(.7, .5, .02, .02, .01)),
        s(FI, "#4E342E", 4.0, pts(.5 to .6, .42 to .5)), s(FI, "#4E342E", 4.0, pts(.5 to .58, .6 to .48))
    )

    private fun flower() = listOf(
        s(SK, GUIDE, 2.0, ellipse(.5, .35, .25, .25)), s(SK, GUIDE, 2.0, pts(.5 to .6, .5 to .92)),
        s(ST, "#2E7D32", 5.0, (0..10).map { P(.5 + .03 * sin(it * .6), .92 - .5 * it / 10) }),
        s(ST, "#C2185B", 4.0, ellipse(.5, .35, .07, .07, 24))
    ) + (0 until 8).map { i ->
        val a = 2 * PI * i / 8
        s(DE, "#E91E63", 4.0, ellipse(.5 + .13 * cos(a), .35 + .13 * sin(a), .07, .07, 24))
    } + listOf(
        s(DE, "#2E7D32", 4.0, ellipse(.4, .72, .08, .035, 24)), s(DE, "#2E7D32", 4.0, ellipse(.6, .62, .08, .035, 24)),
        s(DE, "#7CB342", 3.0, pts(.1 to .93, .9 to .93))
    ) + (0 until 8).map { i ->
        val a = 2 * PI * i / 8
        s(CO, "#FF7AA8", w(.02), fillEllipse(.5 + .13 * cos(a), .35 + .13 * sin(a), .065, .065, .02))
    } + listOf(
        s(CO, "#FFC107", w(.02), fillEllipse(.5, .35, .065, .065, .02)),
        s(CO, "#66BB6A", w(.03), fillEllipse(.4, .72, .075, .03, .02)), s(CO, "#66BB6A", w(.03), fillEllipse(.6, .62, .075, .03, .02)),
        s(CO, "#2E7D32", 8.0, (0..10).map { P(.5 + .03 * sin(it * .6), .92 - .45 * it / 10) }),
        s(FI, "#AD1457", 3.0, ellipse(.5, .35, .07, .07, 24))
    ) + (0 until 8).map { i ->
        val a = 2 * PI * i / 8
        s(FI, "#AD1457", 3.0, ellipse(.5 + .13 * cos(a), .35 + .13 * sin(a), .07, .07, 24))
    } + listOf(s(FI, "#8D6E00", 3.0, ellipse(.5, .35, .035, .035, 16)))

    private fun fish() = listOf(
        s(SK, GUIDE, 2.0, ellipse(.45, .5, .25, .15)), s(SK, GUIDE, 2.0, pts(.2 to .5, .9 to .5)),
        s(ST, "#E65100", 5.0, ellipse(.45, .5, .25, .15)),
        s(ST, "#E65100", 5.0, pts(.68 to .5, .88 to .35, .88 to .65, .68 to .5)),
        s(DE, "#E65100", 4.0, pts(.45 to .36, .5 to .25, .6 to .38)),
        s(DE, "#E65100", 4.0, pts(.45 to .64, .5 to .72, .58 to .62)),
        s(DE, "#4FC3F7", 3.0, ellipse(.15, .3, .03, .03, 12)), s(DE, "#4FC3F7", 3.0, ellipse(.11, .22, .02, .02, 12)), s(DE, "#4FC3F7", 3.0, ellipse(.15, .14, .035, .035, 12)),
        s(DE, "#2E7D32", 4.0, (0..8).map { P(.85 + .02 * sin(it * 1.5), .95 - .15 * it / 8) }),
        s(DE, "#2E7D32", 4.0, (0..8).map { P(.78 + .02 * sin(it * 1.5), .95 - .1 * it / 8) }),
        s(CO, "#FF9F43", w(.02), fillEllipse(.45, .5, .24, .14, .02)),
        s(CO, "#FF7043", w(.02), fillTriH(.68, .88, .5, .15, .02)),
        s(FI, "#BF360C", 3.0, ellipse(.45, .5, .25, .15)), s(FI, "#BF360C", 3.0, pts(.68 to .5, .88 to .35, .88 to .65, .68 to .5)),
        s(FI, "#FFFFFF", 8.0, ellipse(.3, .46, .028, .028, 14)), s(FI, "#111111", 3.0, ellipse(.3, .46, .028, .028, 14)),
        s(FI, "#111111", 5.0, ellipse(.305, .46, .01, .01, 8)),
        s(FI, "#BF360C", 3.0, (0..8).map { val a = -PI / 2 + PI * it / 8; P(.36 + .05 * cos(a), .5 + .12 * sin(a)) }),
        s(FI, "#BF360C", 3.0, pts(.2 to .53, .24 to .55)),
        s(FI, "#BF360C", 2.0, (0..6).map { val a = PI * it / 6; P(.5 + .03 * cos(a), .43 + .03 * sin(a)) }),
        s(FI, "#BF360C", 2.0, (0..6).map { val a = PI * it / 6; P(.58 + .03 * cos(a), .5 + .03 * sin(a)) }),
        s(FI, "#BF360C", 2.0, (0..6).map { val a = PI * it / 6; P(.5 + .03 * cos(a), .57 + .03 * sin(a)) })
    )

    private fun cat() = listOf(
        s(SK, GUIDE, 2.0, ellipse(.5, .35, .2, .17)), s(SK, GUIDE, 2.0, ellipse(.5, .7, .22, .2)),
        s(ST, "#5D4037", 5.0, ellipse(.5, .7, .22, .2)),
        s(ST, "#5D4037", 5.0, ellipse(.5, .35, .2, .17)),
        s(ST, "#5D4037", 5.0, pts(.33 to .25, .3 to .1, .43 to .2)), s(ST, "#5D4037", 5.0, pts(.67 to .25, .7 to .1, .57 to .2)),
        s(DE, "#5D4037", 5.0, (0..12).map { val t = it / 12.0; P(.7 + .18 * t, .82 - .32 * t + .05 * sin(t * 6)) }),
        s(DE, "#5D4037", 4.0, ellipse(.42, .88, .06, .03, 16)), s(DE, "#5D4037", 4.0, ellipse(.58, .88, .06, .03, 16)),
        s(DE, "#8D6E63", 3.0, pts(.2 to .42, .33 to .44)), s(DE, "#8D6E63", 3.0, pts(.2 to .47, .33 to .47)), s(DE, "#8D6E63", 3.0, pts(.2 to .52, .33 to .5)),
        s(DE, "#8D6E63", 3.0, pts(.8 to .42, .67 to .44)), s(DE, "#8D6E63", 3.0, pts(.8 to .47, .67 to .47)), s(DE, "#8D6E63", 3.0, pts(.8 to .52, .67 to .5)),
        s(CO, "#F2A65A", w(.03), fillEllipse(.5, .7, .21, .19, .03)),
        s(CO, "#F2A65A", w(.03), fillEllipse(.5, .35, .19, .16, .03)),
        s(CO, "#F2A65A", w(.03), fillEllipse(.36, .2, .04, .06, .02)), s(CO, "#F2A65A", w(.03), fillEllipse(.64, .2, .04, .06, .02)),
        s(CO, "#F2A65A", 8.0, (0..12).map { val t = it / 12.0; P(.7 + .18 * t, .82 - .32 * t + .05 * sin(t * 6)) }),
        s(CO, "#FFC0CB", w(.015), fillEllipse(.5, .405, .018, .013, .01)),
        s(FI, "#3E2723", 3.0, ellipse(.5, .35, .2, .17)), s(FI, "#3E2723", 3.0, pts(.33 to .25, .3 to .1, .43 to .2)), s(FI, "#3E2723", 3.0, pts(.67 to .25, .7 to .1, .57 to .2)),
        s(FI, "#FFFFFF", 9.0, ellipse(.42, .33, .028, .038, 14)), s(FI, "#FFFFFF", 9.0, ellipse(.58, .33, .028, .038, 14)),
        s(FI, "#2E7D32", 5.0, ellipse(.42, .33, .02, .03, 12)), s(FI, "#2E7D32", 5.0, ellipse(.58, .33, .02, .03, 12)),
        s(FI, "#111111", 4.0, pts(.42 to .3, .42 to .36)), s(FI, "#111111", 4.0, pts(.58 to .3, .58 to .36)),
        s(FI, "#3E2723", 3.0, pts(.5 to .43, .47 to .46)), s(FI, "#3E2723", 3.0, pts(.5 to .43, .53 to .46)),
        s(FI, "#3E2723", 3.0, pts(.45 to .24, .47 to .2)), s(FI, "#3E2723", 3.0, pts(.55 to .24, .53 to .2)),
        s(FI, "#3E2723", 3.0, pts(.5 to .22, .5 to .18))
    )

    // ---- helpers ----
    private fun s(ph: DrawPhase, c: String, w: Double, p: List<Point>) = PenStroke(p, c, w.toFloat(), ph)
    private fun w(step: Double) = step * 360 + 3 // largura que cobre o espaçamento do preenchimento
    private fun P(x: Double, y: Double) = Point(x.toFloat(), y.toFloat())
    private fun pts(vararg p: Pair<Double, Double>) = p.map { P(it.first, it.second) }
    private fun ellipse(cx: Double, cy: Double, rx: Double, ry: Double, n: Int = 40) =
        List(n + 1) { val a = 2 * PI * it / n; P(cx + rx * cos(a), cy + ry * sin(a)) }
    private fun rect(x0: Double, y0: Double, x1: Double, y1: Double) = pts(x0 to y0, x1 to y0, x1 to y1, x0 to y1, x0 to y0)

    private fun zigzag(rows: List<Triple<Double, Double, Double>>): List<Point> { // (y, xLeft, xRight)
        val o = ArrayList<Point>(); var left = true
        for ((y, a, b) in rows) { if (left) { o.add(P(a, y)); o.add(P(b, y)) } else { o.add(P(b, y)); o.add(P(a, y)) }; left = !left }
        return o
    }
    private fun ys(from: Double, to: Double, step: Double): List<Double> {
        val l = ArrayList<Double>(); var y = from; while (y <= to) { l.add(y); y += step }; return l
    }
    private fun fillRect(x0: Double, y0: Double, x1: Double, y1: Double, step: Double = .03) =
        zigzag(ys(y0, y1, step).map { Triple(it, x0, x1) })
    private fun fillEllipse(cx: Double, cy: Double, rx: Double, ry: Double, step: Double = .03) =
        zigzag(ys(cy - ry, cy + ry, step).map { y ->
            val t = (y - cy) / ry; val dx = rx * sqrt(max(0.0, 1 - t * t)); Triple(y, cx - dx, cx + dx)
        })
    /** Triângulo com ápice em cima. */
    private fun fillTri(cx: Double, apexY: Double, baseY: Double, hw: Double, fromY: Double, toY: Double, step: Double = .03) =
        zigzag(ys(fromY, toY, step).map { y -> val dx = hw * (y - apexY) / (baseY - apexY); Triple(y, cx - dx, cx + dx) })
    /** Triângulo horizontal (ápice à esquerda, base à direita), preenchido com linhas verticais. */
    private fun fillTriH(apexX: Double, baseX: Double, cy: Double, halfH: Double, step: Double = .02): List<Point> {
        val o = ArrayList<Point>(); var x = apexX + step; var down = true
        while (x <= baseX) {
            val h = halfH * (x - apexX) / (baseX - apexX)
            if (down) { o.add(P(x, cy - h)); o.add(P(x, cy + h)) } else { o.add(P(x, cy + h)); o.add(P(x, cy - h)) }
            down = !down; x += step
        }
        return o
    }
}
