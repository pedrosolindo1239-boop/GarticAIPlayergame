package com.garticai.player.feature.guess

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.garticai.player.domain.GuessHypothesis
import com.garticai.player.feature.AppViewModel
import kotlin.math.roundToInt

@Composable
fun GuessScreen(vm: AppViewModel, onBack: () -> Unit) {
    val g = vm.guess
    var letters by rememberSaveable { mutableStateOf("") }
    var hint by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let(vm::loadImage) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Voltar") }
            Text("AI GUESS", style = MaterialTheme.typography.titleLarge)
        }
        Button({ picker.launch("image/*") }, Modifier.fillMaxWidth().height(56.dp)) { Text("Importar imagem / captura de tela") }
        g.bitmap?.let {
            Image(it.asImageBitmap(), "Imagem importada", Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Fit)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(letters, { letters = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), singleLine = true,
                label = { Text("Nº de letras") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(hint, { hint = it.take(100) }, Modifier.weight(2f), singleLine = true, label = { Text("Dica (opcional)") })
        }
        Button({ vm.analyze(letters, hint) }, Modifier.fillMaxWidth(), enabled = g.bitmap != null && !g.loading) {
            Text(if (g.result == null) "Analisar" else "Analisar novamente")
        }
        if (g.loading) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
            Text("Claude está analisando o desenho…")
            TextButton({ vm.cancelGuess() }) { Text("Cancelar") }
        }
        g.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        g.result?.let { list ->
            if (list.isEmpty()) Text("Nenhuma hipótese. Tente uma imagem mais clara.")
            Group("Alta confiança", list.filter { it.confidence >= .7f })
            Group("Média confiança", list.filter { it.confidence >= .4f && it.confidence < .7f })
            Group("Baixa confiança", list.filter { it.confidence < .4f })
            Text("O desenho evoluiu? Importe uma nova captura e toque em “Analisar novamente”.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun Group(title: String, items: List<GuessHypothesis>) {
    if (items.isEmpty()) return
    Text(title, style = MaterialTheme.typography.titleMedium)
    items.forEach { h ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(h.answer, style = MaterialTheme.typography.titleMedium)
                    Text("${(h.confidence * 100).roundToInt()}%")
                }
                LinearProgressIndicator(progress = { h.confidence.coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
                if (h.reason.isNotBlank()) Text(h.reason, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
