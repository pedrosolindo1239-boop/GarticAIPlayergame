package com.garticai.player.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.garticai.player.domain.ClaudeStatus
import com.garticai.player.feature.AppViewModel
import com.garticai.player.ui.nav.Routes
import com.garticai.player.ui.theme.Blue

@Composable
fun HomeScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    LaunchedEffect(Unit) { vm.checkClaude() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(32.dp))
        Text("GARTIC AI PLAYER", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Text(vm.claude.label, color = if (vm.claude == ClaudeStatus.ONLINE) Color(0xFF4ADE80) else Color.Gray)
        TextButton({ vm.checkClaude() }) { Text("Verificar conexão") }
        BigButton("AI DRAW") { onNavigate(Routes.DRAW) }
        BigButton("AI GUESS", Blue) { onNavigate(Routes.GUESS) }
        BigButton("Demonstração (offline)", MaterialTheme.colorScheme.surface) { onNavigate(Routes.DEMO) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton({ onNavigate(Routes.HISTORY) }) { Text("Histórico") }
            OutlinedButton({ onNavigate(Routes.SETTINGS) }) { Text("Configurações") }
        }
    }
}

@Composable
private fun BigButton(label: String, color: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = color)) {
        Text(label, style = MaterialTheme.typography.titleMedium)
    }
