package com.garticai.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)
val Bg = Color(0xFF0B0B14)
val Surface1 = Color(0xFF151526)

private val Scheme = darkColorScheme(
    primary = Purple, secondary = Blue, background = Bg,
    surface = Surface1, onPrimary = Color.White, onBackground = Color(0xFFEDEDF7), onSurface = Color(0xFFEDEDF7)
)

@Composable
fun GarticTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
