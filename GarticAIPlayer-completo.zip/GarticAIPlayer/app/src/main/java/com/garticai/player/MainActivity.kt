package com.garticai.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.garticai.player.ui.nav.AppNav
import com.garticai.player.ui.theme.GarticTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GarticTheme { AppNav() } }
    }
}
