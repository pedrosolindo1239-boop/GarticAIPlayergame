package com.garticai.player.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.garticai.player.domain.*
import com.garticai.player.feature.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    var url by rememberSaveable { mutableStateOf(vm.settings.backendUrl) }
    var token by rememberSaveable { mutableStateOf(vm.settings.token) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Voltar") }
            Text("Configurações", style = MaterialTheme.typography.titleLarge)
        }
        Text("Velocidade do desenho")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Speed.values().forEach { s -> FilterChip(vm.settings.speed == s, { vm.updateSettings(vm.settings.copy(speed = s)) }, { Text(s.label) }) }
        }
        Text("Qualidade")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.values().forEach { q -> FilterChip(vm.settings.quality == q, { vm.updateSettings(vm.settings.copy(quality = q)) }, { Text(q.label) }) }
        }
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("URL do backend") })
        OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Token do app (APP_TOKEN, opcional)") }, visualTransformation = PasswordVisualTransformation())
        Button({
            vm.updateSettings(vm.settings.copy(backendUrl = url.trim(), token = token.trim()))
            vm.checkClaude()
        }, Modifier.fillMaxWidth()) { Text("Salvar e testar conexão") }
        Text(vm.claude.label)
        vm.claudeError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("Dica: em celular físico use a URL HTTPS do backend publicado; 10.0.2.2 só funciona no emulador.", style = MaterialTheme.typography.bodySmall)
    }
}
