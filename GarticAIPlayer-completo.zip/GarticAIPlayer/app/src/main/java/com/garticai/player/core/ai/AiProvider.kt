package com.garticai.player.core.ai

import com.garticai.player.domain.*

/** Abstração para permitir trocar/adicionar outras IAs no futuro. */
interface AiProvider {
    suspend fun planDrawing(word: String, quality: Quality): Result<DrawingPlan>
    suspend fun guess(imageJpeg: ByteArray, letterCount: Int?, hint: String?): Result<GuessResult>
    /** true = backend online e com chave do Claude configurada. */
    suspend fun health(): Result<Boolean>
}
