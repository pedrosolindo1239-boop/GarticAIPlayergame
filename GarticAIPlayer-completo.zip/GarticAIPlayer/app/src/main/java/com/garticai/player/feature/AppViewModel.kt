package com.garticai.player.feature

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.garticai.player.core.ai.ClaudeBackendProvider
import com.garticai.player.core.draw.DrawTiming
import com.garticai.player.core.draw.LocalPlanner
import com.garticai.player.data.Prefs
import com.garticai.player.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class DrawUi(
    val word: String = "",
    val loading: Boolean = false,
    val strokes: List<PenStroke> = emptyList(),
    val strokeIndex: Int = 0,
    val pointIndex: Int = 0,
    val phase: DrawPhase? = null,
    val running: Boolean = false,
    val paused: Boolean = false,
    val finished: Boolean = false,
    val error: String? = null,
    val canFallback: Boolean = false
) {
    val progress: Float get() = if (strokes.isEmpty()) 0f else strokeIndex.toFloat() / strokes.size
}

data class GuessUi(
    val bitmap: Bitmap? = null,
    val loading: Boolean = false,
    val result: List<GuessHypothesis>? = null,
    val error: String? = null
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val provider = ClaudeBackendProvider({ settings.backendUrl }, { settings.token })

    var settings by mutableStateOf(prefs.loadSettings()); private set
    var history by mutableStateOf(prefs.loadHistory()); private set
    var claude by mutableStateOf(ClaudeStatus.UNKNOWN); private set
    var claudeError by mutableStateOf<String?>(null); private set
    var draw by mutableStateOf(DrawUi()); private set
    var guess by mutableStateOf(GuessUi()); private set

    private var drawJob: Job? = null
    private var guessJob: Job? = null
    private var lastPlan: DrawingPlan? = null

    fun updateSettings(s: Settings) { settings = s; prefs.saveSettings(s) }

    fun clearHistory() { history = emptyList(); prefs.saveHistory(history) }
    private fun addHistory(e: HistoryEntry) { history = (listOf(e) + history).take(50); prefs.saveHistory(history) }

    fun checkClaude() {
        viewModelScope.launch {
            claude = ClaudeStatus.CHECKING; claudeError = null
            provider.health().fold(
                onSuccess = { claude = if (it) ClaudeStatus.ONLINE else ClaudeStatus.NO_KEY },
                onFailure = { claude = ClaudeStatus.OFFLINE; claudeError = it.message }
            )
        }
    }

    // ---------- AI DRAW ----------
    /** demo = planejador offline; fallback = usar offline após falha do backend. */
    fun startDraw(word: String, offline: Boolean) {
        val w = word.trim()
        if (w.isEmpty()) { draw = draw.copy(error = "Digite uma palavra."); return }
        cancelDraw()
        drawJob = viewModelScope.launch {
            draw = DrawUi(word = w, loading = true)
            val plan: DrawingPlan? = if (offline) {
                LocalPlanner.plan(w).also {
                    if (it == null) draw = DrawUi(word = w, error = "Palavra indisponível offline. Disponíveis: ${LocalPlanner.supportedWords.joinToString()}.")
                }
            } else {
                provider.planDrawing(w, settings.quality).fold(
                    onSuccess = { it },
                    onFailure = {
                        draw = DrawUi(word = w, error = it.message ?: "Erro desconhecido.", canFallback = LocalPlanner.plan(w) != null)
                        null
                    }
                )
            }
            if (plan != null) play(plan, record = true)
        }
    }

    fun restartDraw() {
        val plan = lastPlan ?: return
        cancelDraw()
        drawJob = viewModelScope.launch { play(plan, record = false) }
    }

    private suspend fun play(plan: DrawingPlan, record: Boolean) {
        lastPlan = plan
        val strokes = plan.strokes.map { it.copy(points = DrawTiming.densify(it.points)) }
        draw = DrawUi(word = plan.word, strokes = strokes, running = true)
        val rnd = Random.Default
        for (i in strokes.indices) {
            val st = strokes[i]
            draw = draw.copy(strokeIndex = i, pointIndex = 0, phase = st.phase)
            var p = 0
            while (p < st.points.size) {
                while (draw.paused) delay(60)
                p = min(st.points.size, p + DrawTiming.pointsPerTick(settings.speed))
                draw = draw.copy(pointIndex = p)
                delay(DrawTiming.tickDelayMs(settings.speed, rnd))
            }
            draw = draw.copy(strokeIndex = i + 1, pointIndex = 0)
            delay(DrawTiming.strokePauseMs(settings.speed, rnd))
        }
        draw = draw.copy(running = false, finished = true, phase = null)
        if (record) addHistory(HistoryEntry("DRAW", plan.word, "${strokes.size} traços", System.currentTimeMillis()))
    }

    fun togglePause() { draw = draw.copy(paused = !draw.paused) }

    fun cancelDraw() {
        drawJob?.cancel(); drawJob = null
        draw = draw.copy(running = false, loading = false, paused = false)
    }

    // ---------- AI GUESS ----------
    fun loadImage(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeScaled(uri, 1024) }
            guess = if (bmp == null) guess.copy(error = "Não foi possível abrir a imagem.") else GuessUi(bitmap = bmp)
        }
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? = try {
        val cr = getApplication<Application>().contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        raw?.let {
            val scale = min(1f, maxSide.toFloat() / max(it.width, it.height))
            if (scale < 1f) Bitmap.createScaledBitmap(it, (it.width * scale).toInt(), (it.height * scale).toInt(), true) else it
        }
    } catch (e: Exception) { null }

    fun analyze(letters: String, hint: String) {
        val bmp = guess.bitmap ?: return
        guessJob?.cancel()
        guessJob = viewModelScope.launch {
            guess = guess.copy(loading = true, error = null)
            val bytes = withContext(Dispatchers.Default) {
                ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
            }
            provider.guess(bytes, letters.toIntOrNull(), hint.trim().ifBlank { null }).fold(
                onSuccess = {
                    guess = guess.copy(loading = false, result = it.hypotheses)
                    val top = it.hypotheses.firstOrNull()
                    addHistory(HistoryEntry("GUESS", top?.answer ?: "(sem palpite)",
                        top?.let { t -> "${(t.confidence * 100).toInt()}% de confiança" } ?: "", System.currentTimeMillis()))
                },
                onFailure = { guess = guess.copy(loading = false, error = it.message ?: "Erro desconhecido.") }
            )
        }
    }

    fun cancelGuess() { guessJob?.cancel(); guessJob = null; guess = guess.copy(loading = false) }
    fun cancelAll() { cancelDraw(); cancelGuess() }

    override fun onCleared() { cancelAll() }
}
