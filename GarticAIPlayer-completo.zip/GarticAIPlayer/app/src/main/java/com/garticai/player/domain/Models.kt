package com.garticai.player.domain

enum class Speed(val label: String) { SLOW("Lenta"), MEDIUM("Média"), FAST("Rápida") } // padrão: MEDIUM
enum class Quality(val label: String) { STANDARD("Padrão"), HIGH("Alta") }
enum class DrawPhase(val label: String) {
    SKETCH("Esboço inicial"), STRUCTURE("Estrutura principal"), DETAIL("Detalhamento"),
    COLOR("Coloração"), FINISH("Acabamento")
}

data class Point(val x: Float, val y: Float) // coordenadas normalizadas 0..1
data class PenStroke(val points: List<Point>, val colorHex: String, val width: Float, val phase: DrawPhase)
data class DrawingPlan(val word: String, val strokes: List<PenStroke>)

data class GuessHypothesis(val answer: String, val confidence: Float, val reason: String)
data class GuessResult(val hypotheses: List<GuessHypothesis>)

data class HistoryEntry(val type: String, val title: String, val detail: String, val time: Long)
data class Settings(
    val speed: Speed = Speed.MEDIUM,
    val quality: Quality = Quality.STANDARD,
    val backendUrl: String = "http://10.0.2.2:8787",
    val token: String = ""
)

enum class ClaudeStatus(val label: String) {
    UNKNOWN("Claude: não verificado"), CHECKING("Claude: verificando…"), ONLINE("Claude: conectado"),
    NO_KEY("Backend online, mas sem chave do Claude"), OFFLINE("Claude: backend indisponível")
}

class ApiException(message: String) : Exception(message)
