package com.garticai.player.core.draw

import com.garticai.player.domain.Point
import com.garticai.player.domain.Speed
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.random.Random

/** Ritmo do desenho: três velocidades, com pequenas variações para um traço mais orgânico. */
object DrawTiming {
    fun pointsPerTick(s: Speed) = when (s) { Speed.SLOW -> 1; Speed.MEDIUM -> 2; Speed.FAST -> 4 }

    fun tickDelayMs(s: Speed, rnd: Random): Long {
        val base = when (s) { Speed.SLOW -> 22.0; Speed.MEDIUM -> 16.0; Speed.FAST -> 10.0 }
        return (base * (0.7 + rnd.nextDouble() * 0.7)).toLong().coerceAtLeast(1)
    }

    fun strokePauseMs(s: Speed, rnd: Random): Long {
        val base = when (s) { Speed.SLOW -> 260.0; Speed.MEDIUM -> 140.0; Speed.FAST -> 60.0 }
        return (base * (0.6 + rnd.nextDouble() * 0.9)).toLong()
    }

    /** Insere pontos intermediários para a animação ficar suave. */
    fun densify(points: List<Point>, maxStep: Float = 0.012f): List<Point> {
        if (points.size < 2) return points
        val out = ArrayList<Point>()
        out.add(points.first())
        for (i in 1 until points.size) {
            val a = points[i - 1]; val b = points[i]
            val n = ceil(hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()) / maxStep).toInt().coerceAtLeast(1)
            for (k in 1..n) out.add(Point(a.x + (b.x - a.x) * k / n, a.y + (b.y - a.y) * k / n))
        }
        return out
    }
}
