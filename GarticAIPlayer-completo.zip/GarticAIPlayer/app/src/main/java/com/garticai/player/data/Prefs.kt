package com.garticai.player.data

import android.content.Context
import com.garticai.player.BuildConfig
import com.garticai.player.domain.*
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gartic_ai_player", Context.MODE_PRIVATE)

    fun loadSettings(): Settings {
        val d = Settings(backendUrl = BuildConfig.BACKEND_URL)
        return Settings(
            speed = try { Speed.valueOf(sp.getString("speed", "") ?: "") } catch (e: IllegalArgumentException) { d.speed },
            quality = try { Quality.valueOf(sp.getString("quality", "") ?: "") } catch (e: IllegalArgumentException) { d.quality },
            backendUrl = sp.getString("backendUrl", d.backendUrl) ?: d.backendUrl,
            token = sp.getString("token", "") ?: ""
        )
    }

    fun saveSettings(s: Settings) {
        sp.edit().putString("speed", s.speed.name).putString("quality", s.quality.name)
            .putString("backendUrl", s.backendUrl).putString("token", s.token).apply()
    }

    fun loadHistory(): List<HistoryEntry> = try {
        val a = JSONArray(sp.getString("history", "[]") ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryEntry(o.getString("type"), o.getString("title"), o.getString("detail"), o.getLong("time"))
        }
    } catch (e: org.json.JSONException) { emptyList() }

    fun saveHistory(list: List<HistoryEntry>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("type", it.type).put("title", it.title).put("detail", it.detail).put("time", it.time)) }
        sp.edit().putString("history", a.toString()).apply()
    }
}
