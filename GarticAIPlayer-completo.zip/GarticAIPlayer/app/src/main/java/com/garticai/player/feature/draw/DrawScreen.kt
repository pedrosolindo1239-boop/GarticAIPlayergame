package com.garticai.player.feature.draw

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.unit.dp
import com.garticai.player.core.draw.LocalPlanner
import com.garticai.player.domain.*
import com.garticai.player.feature.AppViewModel
import com.garticai.player.feature.DrawUi

@Composable
fun DrawScreen(vm: AppViewModel, demo: Boolean, onBack: () -> Unit) {
    var word by rememberSaveable { mutableStateOf(if (demo) "casa" else "") }
    val d = vm.draw
    val busy = d.running || d.loading
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Voltar") }
            Text(if (demo) "Demonstração (offline)" else "AI DRAW", style = MaterialTheme.typography.titleLarge)
        }
        OutlinedTextField(
            word, { word = it }, Modifier.fillMaxWidth(), singleLine = true, enabled = !busy,
            label = { Text("Palavra (ambiente de teste)") }
        )
        if (demo) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LocalPlanner.supportedWords.forEach { AssistChip({ word = it }, { Text(it) }) }
        }
        Text("Velocidade")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Speed.values().forEach { sp ->
                FilterChip(vm.settings.speed == sp, { vm.updateSettings(vm.settings.copy(speed = sp)) }, { Text(sp.label) })
            }
        }
        if (!demo) {
            Text("Qualidade")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Quality.values().forEach { q ->
                    FilterChip(vm.settings.quality == q, { vm.updateSettings(vm.settings.copy(quality = q)) }, { Text(q.label) }, enabled = !busy)
                }
            }
        }
        DrawCanvas(d)
        if (d.loading) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
            Text(if (demo) "Preparando desenho…" else "Claude está planejando os traços…")
        } else if (d.strokes.isNotEmpty()) {
            LinearProgressIndicator(progress = { d.progress }, Modifier.fillMaxWidth())
            Text(
                when {
                    d.finished -> "Concluído ✓"
                    d.paused -> "Pausado"
                    else -> d.phase?.label ?: ""
                }
            )
        }
        d.error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            if (d.canFallback) OutlinedButton({ vm.startDraw(word, offline = true) }) { Text("Usar desenho offline") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.startDraw(word, offline = demo) }, Modifier.weight(1f), enabled = !busy) { Text("Iniciar") }
            Button({ vm.togglePause() }, Modifier.weight(1f), enabled = d.running) { Text(if (d.paused) "Continuar" else "Pausar") }
            OutlinedButton({ vm.restartDraw() }, Modifier.weight(1f), enabled = d.strokes.isNotEmpty()) { Text("Reiniciar") }
        }
    }
}

private fun parseColor(hex: String): Color =
    try { Color(android.graphics.Color.parseColor(hex)) } catch (e: IllegalArgumentException) { Color.DarkGray }

@Composable
fun DrawCanvas(d: DrawUi) {
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White)) {
        val k = size.width / 360f
        fun render(s: PenStroke, count: Int) {
            if (count < 2) return
            val path = Path()
            for (i in 0 until minOf(count, s.points.size)) {
                val p = s.points[i]
                if (i == 0) path.moveTo(p.x * size.width, p.y * size.height) else path.lineTo(p.x * size.width, p.y * size.height)
            }
            drawPath(path, parseColor(s.colorHex), style = DrawStroke(s.width * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        d.strokes.forEachIndexed { i, s ->
            if (i < d.strokeIndex) render(s, s.points.size) else if (i == d.strokeIndex) render(s, d.pointIndex)
        }
    }
}
