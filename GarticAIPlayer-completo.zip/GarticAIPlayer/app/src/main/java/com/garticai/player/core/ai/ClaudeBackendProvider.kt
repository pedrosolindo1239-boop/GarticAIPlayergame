package com.garticai.player.core.ai

import android.util.Base64
import com.garticai.player.domain.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.*

/** Fala SOMENTE com o backend próprio; a chave do Claude nunca está no app. */
class ClaudeBackendProvider(
    private val baseUrl: () -> String,
    private val token: () -> String
) : AiProvider {

    private suspend fun call(method: String, path: String, body: JSONObject?): JSONObject =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(baseUrl().trim().trimEnd('/') + path).openConnection() as HttpURLConnection
                conn.requestMethod = method
                conn.connectTimeout = 15_000
                conn.readTimeout = 120_000
                token().takeIf { it.isNotBlank() }?.let { conn.setRequestProperty("x-app-token", it) }
                if (body != null) {
                    conn.doOutput = true
                    conn.setRequestProperty("content-type", "application/json")
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val msg = try { JSONObject(text).optString("error") } catch (e: JSONException) { "" }
                    throw ApiException(msg.ifBlank { "Erro do servidor ($code)" })
                }
                JSONObject(text)
            } catch (e: ApiException) { throw e
            } catch (e: CancellationException) { throw e
            } catch (e: MalformedURLException) { throw ApiException("URL do backend inválida.")
            } catch (e: UnknownHostException) { throw ApiException("Servidor não encontrado. Verifique a URL do backend e a internet.")
            } catch (e: ConnectException) { throw ApiException("Não foi possível conectar ao backend. Ele está rodando?")
            } catch (e: SocketTimeoutException) { throw ApiException("O servidor demorou demais para responder.")
            } catch (e: IOException) { throw ApiException("Falha de conexão com o backend.")
            } catch (e: JSONException) { throw ApiException("Resposta inválida do servidor.")
            } finally { conn?.disconnect() }
        }

    override suspend fun health(): Result<Boolean> = try {
        Result.success(call("GET", "/health", null).optBoolean("claudeConfigured", false))
    } catch (e: ApiException) { Result.failure(e) }

    override suspend fun planDrawing(word: String, quality: Quality): Result<DrawingPlan> = try {
        val json = call("POST", "/draw/plan", JSONObject().put("word", word).put("quality", quality.name))
        val arr = json.getJSONArray("strokes")
        val strokes = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val pa = o.getJSONArray("points")
            PenStroke(
                points = (0 until pa.length()).map { j ->
                    val p = pa.getJSONObject(j); Point(p.getDouble("x").toFloat(), p.getDouble("y").toFloat())
                },
                colorHex = o.optString("color", "#222222"),
                width = o.optDouble("width", 4.0).toFloat(),
                phase = try { DrawPhase.valueOf(o.optString("phase", "DETAIL")) } catch (e: IllegalArgumentException) { DrawPhase.DETAIL }
            )
        }
        Result.success(DrawingPlan(word, strokes))
    } catch (e: ApiException) { Result.failure(e)
    } catch (e: JSONException) { Result.failure(ApiException("Plano de desenho inválido recebido.")) }

    override suspend fun guess(imageJpeg: ByteArray, letterCount: Int?, hint: String?): Result<GuessResult> = try {
        val body = JSONObject().put("imageBase64", Base64.encodeToString(imageJpeg, Base64.NO_WRAP))
        letterCount?.let { body.put("letterCount", it) }
        hint?.let { body.put("hint", it) }
        val arr = call("POST", "/guess", body).getJSONArray("hypotheses")
        Result.success(GuessResult((0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            GuessHypothesis(o.getString("answer"), o.optDouble("confidence", 0.0).toFloat(), o.optString("reason"))
        }))
    } catch (e: ApiException) { Result.failure(e)
    } catch (e: JSONException) { Result.failure(ApiException("Resposta de análise inválida.")) }
}
