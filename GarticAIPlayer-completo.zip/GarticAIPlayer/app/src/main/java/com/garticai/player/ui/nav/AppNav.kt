package com.garticai.player.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.garticai.player.feature.AppViewModel
import com.garticai.player.feature.draw.DrawScreen
import com.garticai.player.feature.guess.GuessScreen
import com.garticai.player.feature.history.HistoryScreen
import com.garticai.player.feature.home.HomeScreen
import com.garticai.player.feature.settings.SettingsScreen

object Routes {
    const val HOME = "home"; const val DRAW = "draw"; const val GUESS = "guess"
    const val DEMO = "demo"; const val SETTINGS = "settings"; const val HISTORY = "history"
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val vm: AppViewModel = viewModel()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    // Ao voltar para a tela inicial (botão ou gesto), encerra qualquer operação em andamento.
    LaunchedEffect(route) { if (route == Routes.HOME) vm.cancelAll() }
    val back: () -> Unit = { nav.popBackStack(); Unit }
    NavHost(nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(vm) { nav.navigate(it) } }
        composable(Routes.DRAW) { DrawScreen(vm, demo = false, onBack = back) }
        composable(Routes.DEMO) { DrawScreen(vm, demo = true, onBack = back) }
        composable(Routes.GUESS) { GuessScreen(vm, back) }
        composable(Routes.SETTINGS) { SettingsScreen(vm, back) }
        composable(Routes.HISTORY) { HistoryScreen(vm, back) }
    }
}
