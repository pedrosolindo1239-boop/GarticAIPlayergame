package com.garticai.player.feature.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.garticai.player.feature.AppViewModel
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(vm: AppViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Voltar") }
            Text("Histórico", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            TextButton({ vm.clearHistory() }, enabled = vm.history.isNotEmpty()) { Text("Limpar") }
        }
        if (vm.history.isEmpty()) Text("Nenhuma atividade ainda.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.history) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${if (e.type == "DRAW") "AI DRAW" else "AI GUESS"} · ${e.title}", style = MaterialTheme.typography.titleMedium)
                        Text(e.detail)
                        Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(e.time)), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
