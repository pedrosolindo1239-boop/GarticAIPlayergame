package com.garticai.player

import com.garticai.player.core.draw.DrawTiming
import com.garticai.player.core.draw.LocalPlanner
import com.garticai.player.domain.*
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class CoreTest {
    @Test fun defaultSpeedIsMedium() = assertEquals(Speed.MEDIUM, Settings().speed)

    @Test fun speedsAreOrdered() {
        val r = { Random(1) }
        assertTrue(DrawTiming.tickDelayMs(Speed.SLOW, r()) > DrawTiming.tickDelayMs(Speed.FAST, r()))
        assertTrue(DrawTiming.pointsPerTick(Speed.FAST) > DrawTiming.pointsPerTick(Speed.SLOW))
    }

    @Test fun delaysVaryNaturally() {
        val rnd = Random(7)
        assertTrue((1..50).map { DrawTiming.tickDelayMs(Speed.MEDIUM, rnd) }.toSet().size > 1)
    }

    @Test fun densifyKeepsEndpointsAndSpacing() {
        val out = DrawTiming.densify(listOf(Point(0f, 0f), Point(1f, 0f)), 0.1f)
        assertEquals(Point(0f, 0f), out.first()); assertEquals(Point(1f, 0f), out.last())
        assertEquals(11, out.size)
    }

    @Test fun everyWordHasAllFivePhasesAndValidCoordinates() {
        LocalPlanner.supportedWords.forEach { w ->
            val plan = LocalPlanner.plan(w)!!
            assertEquals(DrawPhase.values().toSet(), plan.strokes.map { it.phase }.toSet())
            // fases em ordem
            assertEquals(plan.strokes.map { it.phase.ordinal }.sorted(), plan.strokes.map { it.phase.ordinal })
            plan.strokes.forEach { s ->
                assertTrue(s.points.size >= 2)
                s.points.forEach { p -> assertTrue("$w fora do quadro: $p", p.x in 0f..1f && p.y in 0f..1f) }
            }
        }
    }

    @Test fun accentsAreNormalizedAndUnknownIsNull() {
        assertNotNull(LocalPlanner.plan("Árvore")); assertNull(LocalPlanner.plan("xyzabc"))
    }
}
