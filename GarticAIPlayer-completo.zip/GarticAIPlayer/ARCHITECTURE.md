# GARTIC AI PLAYER — Arquitetura (Etapa 1)

App Android (Kotlin + Compose) --HTTPS--> Backend próprio (Etapa 6) --> API do Claude
A chave da API fica só no backend (variável de ambiente). O APK nunca a contém.

Pacotes: ui (tema/navegação) · feature (telas) · domain (modelos) · core/ai (AiProvider).
Controle de custo/limites: no backend (rate limit por dispositivo + teto diário).

## Status
| Item | Estado |
|---|---|
| Esqueleto Android, tema, navegação, tela inicial | Escrito, NÃO compilado |
| AI DRAW / AI GUESS / Claude / backend | Pendente (Etapas 2–6) |
| Integração com o Gartic | Sem API pública documentada; só ambiente próprio de demonstração |

## Como compilar
Abra a pasta no Android Studio (ele gera o gradle wrapper) e use Build > Build APK(s).
