import http from "node:http";
import { extractJson, makeLimiter, validatePlan, validateGuess, DRAW_SYSTEM, GUESS_SYSTEM } from "./lib.js";

export function createServer({
  apiKey = process.env.ANTHROPIC_API_KEY,
  appToken = process.env.APP_TOKEN,
  model = process.env.CLAUDE_MODEL || "claude-sonnet-5-5",
  perMinute = Number(process.env.LIMIT_PER_MINUTE || 10),
  perDay = Number(process.env.LIMIT_PER_DAY || 200),
  maxBody = 6 * 1024 * 1024,
  fetchImpl = fetch,
} = {}) {
  const limiter = makeLimiter({ perMinute, perDay });

  async function callClaude(system, content, maxTokens) {
    const res = await fetchImpl("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, max_tokens: maxTokens, system, messages: [{ role: "user", content }] }),
    });
    if (!res.ok) throw Object.assign(new Error(`Claude respondeu ${res.status}`), { status: 502 });
    const data = await res.json();
    return (data.content ?? []).filter(b => b.type === "text").map(b => b.text).join("\n");
  }

  const send = (res, code, obj) => { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };
  const readBody = req => new Promise((ok, fail) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > maxBody) { fail(Object.assign(new Error("Corpo muito grande"), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { ok(JSON.parse(Buffer.concat(chunks).toString() || "{}")); } catch { fail(Object.assign(new Error("JSON inválido"), { status: 400 })); } });
    req.on("error", fail);
  });

  return http.createServer(async (req, res) => {
    try {
      if (req.method === "GET" && req.url === "/health")
        return send(res, 200, { ok: true, claudeConfigured: Boolean(apiKey), model });
      if (req.method !== "POST") return send(res, 404, { error: "Rota não encontrada" });
      if (appToken && req.headers["x-app-token"] !== appToken) return send(res, 401, { error: "Não autorizado" });
      if (!apiKey) return send(res, 503, { error: "Backend sem ANTHROPIC_API_KEY configurada" });
      const lim = limiter(req.socket.remoteAddress ?? "anon");
      if (!lim.ok) return send(res, 429, { error: lim.reason });
      const body = await readBody(req);

      if (req.url === "/draw/plan") {
        const word = String(body.word ?? "").trim().slice(0, 40);
        if (!word) return send(res, 400, { error: "Informe a palavra" });
        const detail = body.quality === "HIGH" ? "Alta qualidade: muitos detalhes (até 300 traços)." : "Qualidade padrão: até 120 traços.";
        const text = await callClaude(DRAW_SYSTEM, `Palavra: "${word}". ${detail}`, 8000);
        return send(res, 200, validatePlan(extractJson(text), word));
      }
      if (req.url === "/guess") {
        if (!body.imageBase64) return send(res, 400, { error: "Envie a imagem" });
        const extra = [body.letterCount ? `A resposta tem ${Number(body.letterCount)} letras.` : "",
                       body.hint ? `Dica: ${String(body.hint).slice(0, 100)}` : ""].filter(Boolean).join(" ");
        const content = [
          { type: "image", source: { type: "base64", media_type: "image/jpeg", data: body.imageBase64 } },
          { type: "text", text: `Qual é o desenho? ${extra}` },
        ];
        return send(res, 200, validateGuess(extractJson(await callClaude(GUESS_SYSTEM, content, 1500))));
      }
      return send(res, 404, { error: "Rota não encontrada" });
    } catch (e) {
      send(res, e.status ?? 500, { error: e.status ? e.message : "Erro interno ao processar a requisição" });
    }
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 8787);
  createServer().listen(port, () => console.log(`Backend na porta ${port}`));
}
