// Funções puras (testáveis) do backend.
export function extractJson(text) {
  const clean = String(text).replace(/```json|```/g, "").trim();
  const s = clean.indexOf("{"), e = clean.lastIndexOf("}");
  if (s < 0 || e < s) throw new Error("Resposta sem JSON");
  return JSON.parse(clean.slice(s, e + 1));
}

export function makeLimiter({ perMinute, perDay, now = () => Date.now() }) {
  const hits = new Map(); // key -> {minute:[ts], day:{date,count}}
  return function check(key) {
    const t = now(), rec = hits.get(key) ?? { minute: [], day: { date: "", count: 0 } };
    rec.minute = rec.minute.filter(x => t - x < 60000);
    const today = new Date(t).toISOString().slice(0, 10);
    if (rec.day.date !== today) rec.day = { date: today, count: 0 };
    if (rec.minute.length >= perMinute) return { ok: false, reason: "Muitas requisições por minuto" };
    if (rec.day.count >= perDay) return { ok: false, reason: "Limite diário atingido" };
    rec.minute.push(t); rec.day.count++; hits.set(key, rec);
    return { ok: true };
  };
}

const clamp01 = v => Math.min(1, Math.max(0, Number(v)));
const PHASES = ["SKETCH", "STRUCTURE", "DETAIL", "COLOR", "FINISH"];

export function validatePlan(raw, word) {
  if (!raw || !Array.isArray(raw.strokes)) throw new Error("Plano inválido");
  const strokes = raw.strokes.slice(0, 400).map(s => ({
    phase: PHASES.includes(s.phase) ? s.phase : "DETAIL",
    color: /^#[0-9a-fA-F]{6}$/.test(s.color) ? s.color : "#222222",
    width: Math.min(40, Math.max(1, Number(s.width) || 4)),
    points: (Array.isArray(s.points) ? s.points : []).slice(0, 200)
      .map(p => ({ x: clamp01(p.x), y: clamp01(p.y) }))
      .filter(p => Number.isFinite(p.x) && Number.isFinite(p.y)),
  })).filter(s => s.points.length >= 2);
  if (strokes.length === 0) throw new Error("Plano sem traços");
  return { word, strokes };
}

export function validateGuess(raw) {
  if (!raw || !Array.isArray(raw.hypotheses)) throw new Error("Palpites inválidos");
  const hypotheses = raw.hypotheses.slice(0, 8).map(h => ({
    answer: String(h.answer ?? "").slice(0, 60),
    confidence: clamp01(h.confidence),
    reason: String(h.reason ?? "").slice(0, 200),
  })).filter(h => h.answer).sort((a, b) => b.confidence - a.confidence);
  return { hypotheses };
}

export const DRAW_SYSTEM = `Você planeja desenhos para um quadro de desenho. Responda SOMENTE com JSON:
{"strokes":[{"phase":"SKETCH|STRUCTURE|DETAIL|COLOR|FINISH","color":"#RRGGBB","width":number,"points":[{"x":0..1,"y":0..1}]}]}
Regras: coordenadas normalizadas (0,0 canto superior esquerdo). Ordene os traços pelas fases:
SKETCH (esboço leve), STRUCTURE (formas principais), DETAIL (detalhes e elementos secundários),
COLOR (preenchimento com traços largos em zigue-zague), FINISH (contornos finais). Use curvas aproximadas por
vários pontos, larguras variadas e várias cores. O desenho deve ser reconhecível. Máximo 300 traços.`;

export const GUESS_SYSTEM = `Você analisa um desenho de um jogo de adivinhação. Responda SOMENTE com JSON:
{"hypotheses":[{"answer":"palavra","confidence":0..1,"reason":"motivo curto"}]}
Dê de 3 a 6 hipóteses em português, ordenadas por confiança. Respeite a quantidade de letras e a dica quando informadas.
Se o desenho estiver incompleto, diga isso nas razões e use confianças baixas. Não chute aleatoriamente.`;
