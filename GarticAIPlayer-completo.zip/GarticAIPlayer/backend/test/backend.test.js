import test from "node:test";
import assert from "node:assert/strict";
import { extractJson, makeLimiter, validatePlan, validateGuess } from "../lib.js";
import { createServer } from "../server.js";

test("extractJson remove cercas de markdown", () => {
  assert.deepEqual(extractJson('```json\n{"a":1}\n```'), { a: 1 });
  assert.throws(() => extractJson("sem json"));
});

test("limiter bloqueia por minuto e por dia", () => {
  let t = Date.UTC(2026, 0, 1);
  const l = makeLimiter({ perMinute: 2, perDay: 3, now: () => t });
  assert.ok(l("a").ok); assert.ok(l("a").ok); assert.equal(l("a").ok, false);
  t += 61000; assert.ok(l("a").ok); t += 61000; assert.equal(l("a").ok, false); // dia
  assert.ok(l("b").ok);
});

test("validatePlan sanitiza coordenadas e cores", () => {
  const p = validatePlan({ strokes: [{ phase: "X", color: "red", width: 999, points: [{ x: -1, y: 2 }, { x: .5, y: .5 }] }, { points: [{ x: 0, y: 0 }] }] }, "sol");
  assert.equal(p.strokes.length, 1);
  assert.equal(p.strokes[0].phase, "DETAIL"); assert.equal(p.strokes[0].color, "#222222");
  assert.equal(p.strokes[0].width, 40); assert.deepEqual(p.strokes[0].points[0], { x: 0, y: 1 });
});

test("validateGuess ordena por confiança", () => {
  const g = validateGuess({ hypotheses: [{ answer: "gato", confidence: .3 }, { answer: "cão", confidence: 2 }, { answer: "" }] });
  assert.equal(g.hypotheses[0].answer, "cão"); assert.equal(g.hypotheses[0].confidence, 1); assert.equal(g.hypotheses.length, 2);
});

async function withServer(opts, fn) {
  const s = createServer(opts); await new Promise(r => s.listen(0, r));
  const base = `http://127.0.0.1:${s.address().port}`;
  try { await fn(base); } finally { s.close(); }
}
const post = (base, path, body, headers = {}) => fetch(base + path, { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(body) });

test("health e erro sem chave", async () => withServer({ apiKey: "" }, async base => {
  assert.equal((await (await fetch(base + "/health")).json()).claudeConfigured, false);
  assert.equal((await post(base, "/draw/plan", { word: "sol" })).status, 503);
}));

test("draw/plan com Claude simulado", async () => {
  const fake = async () => ({ ok: true, json: async () => ({ content: [{ type: "text", text: '{"strokes":[{"phase":"SKETCH","color":"#ff0000","width":3,"points":[{"x":0.1,"y":0.1},{"x":0.9,"y":0.9}]}]}' }] }) });
  await withServer({ apiKey: "k", fetchImpl: fake }, async base => {
    const r = await post(base, "/draw/plan", { word: "sol" });
    assert.equal(r.status, 200); assert.equal((await r.json()).strokes.length, 1);
    assert.equal((await post(base, "/draw/plan", {})).status, 400);
  });
});

test("token do app e limite de taxa", async () => {
  const fake = async () => ({ ok: true, json: async () => ({ content: [{ type: "text", text: '{"hypotheses":[{"answer":"gato","confidence":0.8,"reason":"orelhas"}]}' }] }) });
  await withServer({ apiKey: "k", appToken: "t", perMinute: 1, fetchImpl: fake }, async base => {
    assert.equal((await post(base, "/guess", { imageBase64: "x" })).status, 401);
    assert.equal((await post(base, "/guess", { imageBase64: "x" }, { "x-app-token": "t" })).status, 200);
    assert.equal((await post(base, "/guess", { imageBase64: "x" }, { "x-app-token": "t" })).status, 429);
  });
});

test("falha do Claude vira 502 sem vazar detalhes", async () => {
  await withServer({ apiKey: "k", fetchImpl: async () => ({ ok: false, status: 500 }) }, async base => {
    const r = await post(base, "/draw/plan", { word: "sol" });
    assert.equal(r.status, 502);
  });
});
