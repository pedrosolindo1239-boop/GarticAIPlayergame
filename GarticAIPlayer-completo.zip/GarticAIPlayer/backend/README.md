# Backend (proxy seguro para o Claude)
Requer Node 18+. Sem dependências.
    export ANTHROPIC_API_KEY=sua_chave
    export APP_TOKEN=um_segredo_opcional   # o app envia no header x-app-token
    npm start        # porta 8787
Variáveis: CLAUDE_MODEL (padrão claude-sonnet-5-5), LIMIT_PER_MINUTE (10), LIMIT_PER_DAY (200), PORT.
Rotas: GET /health · POST /draw/plan · POST /guess. Teste: npm test
Para celular físico: publique o backend em HTTPS e altere BACKEND_URL no app (Configurações).
