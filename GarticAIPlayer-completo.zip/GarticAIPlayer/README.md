# GARTIC AI PLAYER

App Android (Kotlin + Jetpack Compose) com **AI DRAW** e **AI GUESS**, usando o Claude via backend próprio.

## Estrutura
- `app/` — projeto Android (ui, feature, domain, core/ai, core/draw, data)
- `backend/` — proxy Node (sem dependências) que guarda a chave, limita uso e chama o Claude
- `.github/workflows/build-apk.yml` — compila o APK na nuvem (GitHub Actions)

## 1) Backend
    cd backend
    export ANTHROPIC_API_KEY=sua_chave
    export APP_TOKEN=segredo_opcional
    npm start          # porta 8787  (npm test roda os testes)

## 2) Gerar o APK (escolha um)
**Android Studio:** abrir a pasta GarticAIPlayer → aguardar o sync → Build > Build APK(s) → app/build/outputs/apk/.
**GitHub Actions:** subir o projeto num repositório → aba Actions → "Build APK" → Run workflow → baixar `app-release`.
O release usa assinatura de DEBUG (só para testes). Para publicar, configure sua própria keystore.

## 3) Instalar
Copie o APK para o celular, permita "instalar apps desconhecidos" e abra o arquivo.
No app: Configurações → URL do backend (HTTPS no celular físico; 10.0.2.2 só no emulador) → Salvar e testar.

## O que está implementado
| Recurso | Estado |
|---|---|
| Tela inicial, navegação, tema escuro roxo/azul, status do Claude | Escrito |
| AI DRAW: planejamento pelo Claude, 5 fases, canvas em tempo real, velocidades Lenta/**Média**/Rápida com variação de ritmo, pausar/reiniciar | Escrito |
| Demonstração offline (sol, casa, árvore, flor, peixe, gato) | Escrito |
| AI GUESS: importar imagem, nº de letras, dica, hipóteses por confiança (re-análise manual com nova captura) | Escrito |
| Histórico, configurações salvas, cancelamento ao voltar | Escrito |
| Backend: chave só no servidor, token opcional, limites por minuto/dia, erros tratados | Escrito e TESTADO |

## Depende de integração externa (NÃO implementado)
Desenhar ou responder dentro do Gartic: não há API documentada, e o projeto não contorna proteções.
Painel flutuante e captura de tela automática exigiriam permissões/serviços próprios do Android (não incluídos).
Hoje: o AI DRAW desenha no canvas do app e o AI GUESS analisa imagens importadas.

## Relatório de testes
- Backend (`npm test`, Node 22, Claude simulado): # pass 8 # fail 0 
- Testes unitários Kotlin (`app/src/test`): escritos, **NÃO executados** (sem Kotlin/Android SDK no ambiente de desenvolvimento).
- **Compilação do APK: NÃO realizada. Instalação e abertura no Android: NÃO testadas.**
- Não testado com a API real do Claude (só com resposta simulada).
